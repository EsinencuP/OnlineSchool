# TASK-030 — Редизайн домашних заданий без потери надёжности редактора

**Пакет:** K8K-FRONTEND-REBUILD v1.0,03.11.2026. **Блок:** 3 — Кабинет ученика. **Модуль:** Уроки и домашние задания.

**Входные зависимости:** [TASK-029](TASK-029.md). Номер относится только к этому пакету, не к старым MGR/Phase0 TASK. **Учёт выполнения:** [EXECUTION_LOG](EXECUTION_LOG.md).

**Исходный статус:** Рабочий редактор уже реализован: debounce2s, последовательные server saves, upload intent, версии, route blocker. Требуется перенос на общий UI-kit, полная RU/RO и проверка неизвестного результата без переписывания жизненного цикла.. Это описание кода на дату составления, не акт приёмки и не команда начать с нуля.

## 1. Команда AI-кодеру и результат

Выполни **только TASK-030** в существующем репозитории. Не начинай следующий TASK автоматически.

Сделать выдачу, выполнение, сдачу и доработку ДЗ ясными ребёнку и сохранить все механизмы защиты ввода. Одна хронологическая выдача и серверный статус важнее сходства с чекбоксами шаблона.

Этот файл содержит необходимые общие правила и предметное задание. Предыдущая переписка, ответы других чатов и внешний COMMON.md не нужны. Локальные исходники/документы ниже нужны для проверки фактической реализации; их ссылки не заменяют сформулированные здесь требования. Если код уже частично существует — ревью, завершение и доказательство вместо повторной реализации.

## 2. Контекст проекта — повторён намеренно

Рабочий репозиторий `D:/OnlineSchool`, существующее ESM pnpm-monorepo. Это функциональный редизайн работающей академии, а не новый проект. Node24, pnpm10.34.9, React18.3.1, Vite7.3.7, TypeScript6.0.3 strict, NestJS/Prisma, PostgreSQL, TanStackQuery и сгенерированный Orval SDK уже используются. Проверяй текущие manifests: перечисленные версии описывают исходную точку пакета03.11.2026, не команду массово обновить зависимости.

В выпуск входят пять кабинетов, общий вход и смена демонстрационного пользователя. Публичный сайт отдельно. Русский и румынский утверждены для всего интерфейса, включая aria-labels, ошибки, валидацию, даты и пустые состояния. Учебные задания, имена, комментарии и сообщения людей автоматически не переводятся. Язык и таймзона — разные настройки; таймзона берётся из авторитетного контекста пользователя.

Уже есть `packages/ui` с токенами, локальными Golos/Lucide, AppShell/StateBoundary/freshness/refresh, базовыми controls и частичной locale-моделью. `account-ui` остаётся границей меню аккаунта/сессии. В текущем инкременте есть Reports, bell pagination/redirect, current-lesson fix и staff section URLs. Это заготовки и ограниченные доказательства, а не завершение всего плана. Не пересоздавай их с нуля. Сначала сравни фактический код с требованием TASK. Выполненное сохрани и проверь; недостающее реализуй. Исторические числа тестов не считать новым прогоном.

Порядок: основа → ученик → преподаватель → менеджер/CRM → необходимые директор/оператор/общий вход → сквозная приёмка. Отдельные недостающие API-инкременты разрешены владельцем03.11.2026 в рамках утверждённых правил. Старый frontend-only запрет в разделе8 K8K-документа исторический; действующий раздел7 и текущий план имеют приоритет.

## 3. Неприкосновенные правила — применить и в этом TASK

1. Сохрани пользовательский dirty/untracked код и архивы. Никаких `reset --hard`, `clean`, удаления чужих файлов, force push или коммита всего дерева. Сначала прочитай status/HEAD; работай ограниченным diff. Существующую ветку не подменять. Если нужна новая — `codex/k8k-task-NNN` с сохранением рабочей основы; без автоматического merge/push/deploy.
2. Приоритет: последняя явная воля владельца → действующие специальные решения/UX → актуальные архитектурные источники → K8K-инструкции → визуальный template. Замороженные исторические акты не переписывать. Ссылки на отсутствующие handoff/backlog/findings не считать их содержимым или доказательством реализации.
3. Экран ничего сам не подтверждает. Календарь, вход в Meet, факт проведения, право на занятие, денежное поступление, распределение, начисление и выплата — разные факты. Не создавать второй ledger или клиентский расчёт прав.
4. Все действия проверяет сервер по `роль × действие × объект × контекст`. Кнопки строятся по реальной action eligibility/capabilities, не по одной строке роли. Передача поступления менеджером на согласование не директорское подтверждение. Подтверждение поступления/распределения и окончательное финансовое решение — директор.
5. Пока совокупно подтверждённая распределённая оплата абонемента ниже полной цены, каждый частичный/рассрочный допуск требует отдельного ограниченного решения директора. Полная оплата даёт нормальный доступ без двойных прав. Снимок/скриншот платежа семьи не подтверждает оплату.
6. Деньги остаются точными decimal strings/существующим Decimal; никаких `Number`/`parseFloat` для сумм. Не смешивать валюты, аванс, нераспределённые средства семьи, остаток уроков и ожидающие поступления. Чужие дети смешанного портфолио/семьи не раскрываются.
7. Обычная ставка преподавателя: `min(6,floor(eligible_full_months/2)) + min(4,floor(active_students/2))`;0–4→200MDL,5–9→220MDL,10→250MDL. Расчёт только сервером, snapshot при фактическом старте. Восстановление стажа при возвращении в пределах6месяцев. Старые +20/+30,230MDL и месячный пересчёт не возвращать. Спор/предварительное начисление/подтверждённая выплата различаются; личные обещанные обязательства не отменять молча.
8. У ученика нет общего чата/«Моих обращений»/пункта «Сообщения» и отдельного центра уведомлений: только колокольчик. Официальные внешние контакты только из разрешённой CRM-проекции. Спецформы переноса/спора остаются в уроке. Новые внешние организационные автонапоминания семье не вводить.
9. ДЗ и история уроков ученика — единые хронологические списки без новых status-tabs. Сдача не checkbox. Черновик/сохранение/загрузка/отправка/проверка раздельны; существующую сериализованную очередь autosave/версий/idempotency не переписывать ради внешнего вида. Просрочка — текст/иконка, не новая санкция.
10. Навыки: три качественных этапа «Знакомлюсь/Практикую/Применяю» плюс техническое «Ещё не изучали». Ни процентов знаний, рейтинга, автоповышения. Циклы4/8 по подтверждённо проведённым урокам каждого предмета; срез4 не отчёт8; публикация требует преподавателя. Неизвестные ретрокоррекции не решать эвристикой.
11. Истечение одного предмета не закрывает другой; заморозка не окончание, ранее разрешённая самостоятельная работа сохраняется. Полная приостановка — простой экран и контакт менеджера; история не удаляется. Нельзя выводить доступ из названия плана или клиентского состояния.
12. Сохрани действующие CSRF, idempotency, no-store, MFA и явно разрешённые scoped password-only исключения. Одноразовый пароль/OTP/cookie/OAuth token не попадает в logs/stories/snapshots/idempotency cache. Logout/401/session switch убирают приватный DOM/кэш и отменяют reads; поздний ответ прежнего actor отбрасывается.403 выше cached stale.
13. Девять UI-классов: loading, empty, ready, stale, error, pending/unknown-result, forbidden, subscription-limited, session-expired. Loading не empty; queued не delivered; unknown не success. Повтор чтения допустим по политике, слепой повтор команды с неизвестным исходом запрещён. Read≠claim≠resolve; серверная эскалация не зависит от браузера.
14. Токены/шрифт/размеры provisional до приёмки. Golos локально, Lucide статически, без CDN/фото людей/emoji actions. WCAG2.2AA, видимый фокус, клавиатура, reduced-motion, статусы текстом и иконкой;4ширины360/768/1024/1280. Основное действие ученика48px, прочие44px; staff touch44px, desktop от36px по контексту. Не скрывать overflow вместо исправления доступа. Бюджет≤250KiB gzip на маршрут по единому методу с учётом fonts.
15. Новый dependency только по необходимости: pinned версия, релиз старше14дней, license MIT/ISC/BSD/Apache-2.0/OFL; MPL-2.0 только соответствующий test tooling, React18 peers; запись причины/веса вui-stack. Никаких Tailwind/Bootstrap/FullCalendarPremium/AGPL/GPL/CC-NC заимствований. Современный сайт vendor не разрешает обновить текущий stack до latest.
16. Одна рабочая Vercel/Neon main. Не создавать staging/QA/disposable БД, не выполнять reset/seed/destructive/concurrency/crash suites на рабочей БД. Unit/HTTP mocks/local browser fixtures разрешены; перед командой проверь её реальное содержимое и env-target. Не читать/печатать .env. Недоказуемые DB/provider проверки остаются BLOCKED/NOT_RUN, неPASS.
17. Во время отдельного TASK только нужные scoped build/generate/lint/tests и короткий smoke. Общую рекурсивную регрессию отложить до финального блока. Авторизованное API-изменение: source DTO/service/controller → безопасные проверки → штатная OpenAPI/SDK генерация → consumers; generated вручную не править. Applied migrations/checksums не переписывать. Подготовить необходимую additive migration можно с описанием сохранения данных; не применять её к рабочей БД в этой задаче без отдельного разрешения.
18. Условные DIR-01…06 остаются выключенными, DIR-07/BI/P&L вне выпуска. .ics, saved filters, offline/PWA/dark mode тоже вне этого пакета. LEGAL/FIN-LEGAL, ретрокоррекции4/8, expanded MeetAPI POC/OAuth/security/G4 и FND-GATE не закрываются наличием экрана или mock-тестом.

## 4. Источники и конкретные входные файлы

Обязательный локальный минимум, повторённый для отдельного чата:

- [AGENTS.md](../../AGENTS.md) — последние owner decisions, source priority, preservation.
- [PHASE0_CHECKS.md](../../PHASE0_CHECKS.md) — первые актуальные ограничения среды; позднейший исторический список не разрешает testDB.
- [docs/K8K_REDESIGN_PLAN.md](../K8K_REDESIGN_PLAN.md) — объём и последовательность.
- [docs/K8K_IMPLEMENTATION_STATUS.md](../K8K_IMPLEMENTATION_STATUS.md) — какие заготовки уже есть и что ещё не доказано.
- [docs/K8K_REQUIREMENTS_MATRIX.md](../K8K_REQUIREMENTS_MATRIX.md) — текущая трассировка и статусы.
- [docs/K8K_DESIGN_INSTRUCTIONS.md](../K8K_DESIGN_INSTRUCTIONS.md) — разделы2–7; раздел8 исторический, не действующий запрет API.
- [docs/online_academy_CON_01_11_owner_decisions_addendum_v1.0.md](../online_academy_CON_01_11_owner_decisions_addendum_v1.0.md) — CON-01…11: деньги, допуск, ставки, публикация; не возвращать старую модель.

Предметные основания именно этого TASK:

- [docs/K8K_Academy_VIS12_dashboard_module_contracts_v1.0.md](../K8K_Academy_VIS12_dashboard_module_contracts_v1.0.md) — **STU-02; V12-AT-04/10/11**: Простой список и реальные серверные статусы.
- [docs/online_academy_student_architecture_full_decision_log_v2.md](../online_academy_student_architecture_full_decision_log_v2.md) — **№10.8/A; №10.9–10.11**: Черновик, версии, вложения, ручная отправка; без новых вкладок.
- [apps/api/src/student/homework/README.md](../../apps/api/src/student/homework/README.md) — **Routes and identity; Lifecycle and persistence; Private direct uploads**: Delivery identity, версии и soft deadline, verified uploads.
- [docs/K8K_DESIGN_INSTRUCTIONS.md](../K8K_DESIGN_INSTRUCTIONS.md) — **§2 п.3; §5.2 DASH-STU-02; §3.3**: Status-chip вместо checkbox, touch targets, stale/pending.
- [apps/student-cabinet/tests/student.spec.mjs](../../apps/student-cabinet/tests/student.spec.mjs) — **debounce; failed save; serialized slow drafts; intent retry**: Существующая поведенческая регрессия, которую нельзя ослаблять.

Реальные точки входа в код/доказательства (существуют на дату пакета; если структура позже изменена, найди symbol через `rg`, не создавай дубликат):

- [apps/student-cabinet/src/pages/Homework.tsx](../../apps/student-cabinet/src/pages/Homework.tsx).
- [apps/student-cabinet/src/components.tsx](../../apps/student-cabinet/src/components.tsx).
- [apps/student-cabinet/src/api.ts](../../apps/student-cabinet/src/api.ts).
- [apps/student-cabinet/src/student.css](../../apps/student-cabinet/src/student.css).
- [apps/student-cabinet/tests/fixture-server.mjs](../../apps/student-cabinet/tests/fixture-server.mjs).
- [apps/student-cabinet/tests/student.spec.mjs](../../apps/student-cabinet/tests/student.spec.mjs).
- [apps/api/src/student/homework/homework.dto.ts](../../apps/api/src/student/homework/homework.dto.ts).
- [apps/api/src/student/homework/homework.service.ts](../../apps/api/src/student/homework/homework.service.ts).
- [packages/ui/src/controls.tsx](../../packages/ui/src/controls.tsx).

Визуальная опора: [template/newtemp.png](../../template/newtemp.png) — язык дизайна, не требования и не источник mock-цифр. Старые [template/*.webp](../../template/README.md) — только исторические примеры.

Инструменты кодера: начинай поиск исходников с `rg`; версии/лицензии проверяй через `pnpm view` и текущий lockfile. Для библиотечных API используй доступный Context7/официальные документы нужной версии; для интерфейса — локальный Playwright/browser harness и проверку реального рендера. Сначала проверь доступность MCP, не считай запись сервера доказательством авторизации. Repo-инструменты и локальные fixtures остаются рабочим fallback. Figma/внешний дизайн-сервис не обязательны для восстановления этого контекста. Не подключай реальные аккаунты/провайдеры ради mock smoke и не подменяй ими ограничения среды.

Официальные справочные сайты по теме; бизнес-контекст уже дан выше, интернет не нужен для его восстановления. Перед использованием API/версии библиотеки сверяй первичную документацию именно совместимой версии. Наличие ссылки не требует установки пакета:

- [React 18.3.1](https://18.react.dev/reference/react) — API текущей major-версии; не обновлять проект до React19 по latest-примеру.
- [TanStack Query v5](https://tanstack.com/query/latest/docs/framework/react/overview) — Чтения, query keys, invalidation, cancellation; выбранную minor сверять с package.json.
- [WCAG 2.2](https://www.w3.org/WAI/WCAG22/quickref/) — Рабочая accessibility-рамка; axe не заменяет ручные проверки.
- [Playwright visual comparisons](https://playwright.dev/docs/test-snapshots) — Воспроизводимые снимки и контролируемые fixtures.
- [Orval](https://orval.dev/) — Генерация SDK только штатным способом проекта.

## 5. Предметные правила и сохранение поведения

- hwId — HomeworkDelivery.id, не общий assignment ID. Статус определяется latest submission/review на сервере; ученик не отмечает выполнение чекбоксом.
- Основной список сохраняет issued_at DESC,id DESC и server pagination. Фразу дизайн-документа о сортировке сроков не применять к полной выдаче вопреки10.8/A; overdue mark не меняет порядок.
- NOT_SUBMITTED/NEEDS_REVISION редактируются; SUBMITTED/REVIEWED не создают новую версию произвольно. Новая версия после доработки сохраняет старые тексты/проверки и attachments.
- Черновик сохраняется сервером с debounce2s и очередью: медленный старый save не перезаписывает новую редакцию. «Сохранено» только после ответа; ошибка не стирает ввод.
- Просрочка мягкая: null deadline допустим, equality server submit time=dueAt не late. Не блокировать сдачу из-за истёкшего срока, не вычислять штраф/оценку/автоповышение навыка.
- Прямая загрузка: nonempty file <=50MiB, не более20; request intent, PUT exact bytes с credentials:omit, затем server confirm VERIFIED. Session/CSRF не передаются S3, URL не хранится в evidence.
- Секреты и private URL не попадают в localStorage/логи. Dirty answer защищает accidental navigation, но auth/suspended redirect не блокируется редактором и очищает чужой контент.

## 6. Контракты, данные и совместимость

- Существующие SDK GET list/detail, PATCH draft, POST upload-url, confirm и submit сохраняются. Body draft = content; submit = content/fileIds; response submit определяет versionNumber/status/isLate.
- У каждой новой draft редакции новый UUID; retry того же submit/upload/confirm intent сохраняет UUID. Same key changed body остаётся ошибкой; новая пользовательская редакция — новое намерение.
- Saved expiresAt относится к server draft TTL30days; expired draft не заменяет текущий неподтверждённый текст. Сохранённая строка сохраняет whitespace, без произвольного trim содержимого ответа.
- PUT на presigned upload URL — единственное уже разрешённое исключение прямого fetch для S3. Другие API calls идут через SDK/transport; не выставлять запрещённый browser Content-Length.

Точные имена новых planned DTO/operation/props запиши в коротком design note этого TASK до реализации и соблюдай существующие namespace/style. Planned нельзя выдавать за уже существующий API. Найденный существующий сервис переиспользуй. Generic UI не принимает бизнес-решения. Существующий авторитетный источник не копируется во второй реестр.

## 7. Пошаговое выполнение

1. Подтверди prerequisites по реальным артефактам предыдущих TASK и текущему коду. Недостающий результат не заменяй заглушкой или флагом с фиктивными данными. Не пересылай пользователю уже закрытые вопросы о чате, уведомлениях или director-only подтверждениях.
2. Зафиксировать текущий HomeworkEditor state machine и существующие тесты до изменения JSX. Составить таблицу draft/save/upload/submit/needs-revision/unknown с разрешёнными контролами и сообщениями.
3. Перенести список на единый ListRow/StatusChip и простой фильтр только в объёме действующего API. Не добавлять табы по состоянию; в summary главной использовать авторитетный следующий/последний элемент без искусственного global count.
4. Разнести в карточке задание преподавателя, поле ответа, вложения, save feedback и явную Отправить/RO. Визуальный disabled не должен терять textarea value или remount editor после refetch.
5. Сохранить queue.current, debounce и flush ordering перед submit; выделение hook допустимо лишь с теми же tests. Не вводить второй autosave в shared Field/StateBoundary.
6. Сохранить uploadIntent по файлу, separate request/confirm UUID, повтор confirm без второго PUT после successful upload и новую заявку при expired URL. Отображать local progress/ошибку без утверждения VERIFIED до API.
7. Сделать явные состояния save failed/retry, submit pending и unknown result. Без ответа не показывать Сдано и не создавать новый intent; проверить серверный detail/version прежде безопасного повтора того же намерения.
8. Сохранить blockers: dirty/unload, отмена ухода, focus return из confirm, безопасное закрытие после сохранения/отправки. На телефоне CTA не перекрывает текст/virtual keyboard/bottom nav.
9. Показать immutable историю версий и публичные текстовые комментарии преподавателя, включая новую доработку. Только plain text/безопасная существующая renderer, никакого raw HTML или числовой оценки.
10. Перенести все подписи/ошибки/aria в RU/RO и выполнить адресные существующие browser scenarios на fixture server. В отчёте отдельно указать, что mock upload не проверяет реальный S3/CORS.
11. Сверь итог с правилами разделов3/5/6 этого же файла, обнови журнал и предметную матрицу, подготовь артефакты и остановись после отчёта по TASK-030.

## 8. Обязательные сценарии проверки

- [ ] Быстрый набор текста создаёт один save после2s; две медленные последовательные редакции сохраняют именно последнюю.
- [ ] Ошибка save оставляет текст editable; retry не сбрасывает cursor/focus; refetch не remounts редактор.
- [ ] Уход с dirty вызывает confirm, отмена возвращает к вводу; 401/suspension redirect не застревает в blocker.
- [ ] Сдача ждёт очередь save; double click/timeout/replay не создают вторую submission version.
- [ ] NEEDS_REVISION разрешает новую версию, SUBMITTED/REVIEWED сохраняют read-only; предыдущая история не пропадает.
- [ ] 0bytes/50MiB+1/21files отклоняются; valid file -> PUT -> confirm; confirm retry не перезаливает файл.
- [ ] Expired URL требует нового upload intent, invalid/foreign file ID отвергает сервер; S3 не получает session cookies.
- [ ] Soft deadline null/equal/late, chronological order, server status, RU/RO и 360px проверены; никакого изменения баланса/навыка.

Для визуального изменения: RU/RO,360/768/1024/1280, keyboard/focus/long text и relevant VIS11 states. Для read-model/API: validation, own/foreign scope, revoked context, no-store, error/empty/unknown и совместимость SDK. Для мутации: CSRF/idempotency/revision/unknown-result и отсутствие двойного эффекта. Не добавляй бессмысленный тест, который просто повторяет строку implementation; доказывай поведение.

## 9. Команды и безопасные границы проверки

Рабочий каталог `D:/OnlineSchool`. Это адресные ориентиры из текущих manifests, а не разрешение слепо запускать все команды. Прочитай scripts/конфиг теста перед запуском. Сборка может генерировать Prisma/SDK; это не разрешение запускать migration/seed или подключать реальную БД. Dist-based tests выполнять после целевой сборки.

```powershell
pnpm test:stu05
```

```powershell
pnpm --filter @online-school/student-cabinet typecheck
```

```powershell
pnpm --filter @online-school/student-cabinet lint
```

```powershell
pnpm --filter @online-school/student-cabinet exec playwright test --config playwright.config.mjs --grep "debounce|failed save|serialized|confirmation|submission"
```

Если нужен новый тестовый script, сначала добавь его в manifest с явно безопасным локальным/mock target, затем запусти и запиши точную команду. Не выполняй `pnpm test`/recursive regression автоматически на каждом TASK. Полный разрешённый прогон относится к финальному блоку. Ошибка не основание ослабить линтер или выдавать NOT_RUN за PASS.

## 10. Критерии готовности

- [ ] Существующие сценарии autosave/retry/версий проходят без ослабления ожиданий.
- [ ] В списке нет чекбоксов выполнения, новых status tabs и client reorder paginated data.
- [ ] Текст/файлы/курсоры не теряются при background read, save error и допустимых переходах.
- [ ] Сдано/Сохранено/VERIFIED показываются только после авторитетного ответа.
- [ ] Unknown submit не вызывает автоматической новой команды с новым ключом.
- [ ] RU/RO, клавиатура и touch targets проверены для списка, редактора, доработки и history.

- [ ] Все использованные данные и действия имеют реальный авторитетный источник/проверку; нет выдуманных цифр, прав, кнопок и success.
- [ ] Отчёт различает исходный работающий код, новые изменения, свежие проверки и исторические доказательства.
- [ ] Не изменены рабочая БД, применённые migration checksums и production; необоснованные внешние эффекты отсутствуют.

## 11. Не входит в этот TASK

- Автопроверяемые тесты, online-document editor, разметка PDF, жёсткие дедлайны, grading и проценты знаний.
- Изменение upload retention, storage policy, real S3 probes или financial writes.

Обнаруженный соседний gap запиши с конкретным следующим TASK, не расширяй текущую задачу на весь redesign. Если требуется реально новое бизнес-решение или недоступный внешний провайдер — подготовь все независимые изменения и точный вопрос/блокер только по этому пункту. Не останавливайся на повторном согласовании ранее утверждённых правил.

## 12. Артефакты и отчёт для следующего кодера

- output/k8k-taskpack/task-030/report.md: исходная версия, изменения, целевые результаты и реальные ограничения.
- output/k8k-taskpack/task-030/acceptance.json: критерии PASS/FAIL/NOT_RUN со ссылками; screenshots RU/RO/viewport для новых представлений.

Формат `output/k8k-tasks/TASK-030/report.md`:

```text
TASK: TASK-030
Статус: DONE / PARTIAL / BLOCKED (не смешивать с исходным статусом заготовки)
Основа: HEAD, ветка, dirty digest, сохранённые чужие изменения
Что уже существовало:
Что изменено: путь → поведение → причина
Контракты/SDK/миграции: actual changes, совместимость, что не применялось
Источники/решения: конкретные IDs и применённый приоритет
Проверки: команда → exit code → сценарии → artifact path
Визуальные доказательства: route, role, locale, viewport, fixture
Не проверено/блокеры: точная причина и необходимое внешнее условие
Acceptance checklist: каждый критерий PASS / FAIL / NOT_RUN
Остатки: конкретный TASK и передаваемые interfaces/URLs/ключи
Риски и обратимость: ограниченный rollback без удаления истории/чужих файлов
```

После отчёта остановись. Следующий TASK выдаёт владелец отдельно. Не добавляй утверждение о FND-GATE/юридическом соответствии/production GO, если такого доказательства и решения нет.
