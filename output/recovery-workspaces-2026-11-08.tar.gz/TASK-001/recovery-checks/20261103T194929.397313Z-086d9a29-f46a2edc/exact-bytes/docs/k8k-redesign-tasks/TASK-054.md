# TASK-054 — Доска заявок: клавиатурные переходы и dnd без обхода workflow

**Пакет:** K8K-FRONTEND-REBUILD v1.0,03.11.2026. **Блок:** 5 — Менеджер и CRM. **Модуль:** Воронка заявок.

**Входные зависимости:** [TASK-053](TASK-053.md). Номер относится только к этому пакету, не к старым MGR/Phase0 TASK. **Учёт выполнения:** [EXECUTION_LOG](EXECUTION_LOG.md).

**Исходный статус:** Частично: board/table переключатель и lead commands есть; drag-and-drop и эквивалентное клавиатурное перемещение не завершены. Серверную полноту обеспечивает TASK-053.. Это описание кода на дату составления, не акт приёмки и не команда начать с нуля.

## 1. Команда AI-кодеру и результат

Выполни **только TASK-054** в существующем репозитории. Не начинай следующий TASK автоматически.

Сделать канбан практичным на мыши/клавиатуре/телефоне, но каждый перенос должен открывать и выполнять тот же разрешённый предметный transition с причинами и CAS, а не произвольный PATCH стадии.

Этот файл содержит необходимые общие правила и предметное задание. Предыдущая переписка, ответы других чатов и внешний COMMON.md не нужны. Локальные исходники/документы ниже нужны для проверки фактической реализации; их ссылки не заменяют сформулированные здесь требования. Если код уже частично существует — ревью, завершение и доказательство вместо повторной реализации.

## 2. Контекст проекта — повторён намеренно

Рабочий репозиторий `D:/OnlineSchool`, существующее ESM pnpm-monorepo. Это функциональный редизайн работающей академии, а не новый проект. Node24, pnpm10.34.9, React18.3.1, Vite7.3.7, TypeScript6.0.3 strict, NestJS/Prisma, PostgreSQL, TanStackQuery и сгенерированный Orval SDK уже используются. Проверяй текущие manifests: перечисленные версии описывают исходную точку пакета03.11.2026, не команду массово обновить зависимости.

В выпуск входят пять кабинетов, общий вход и смена демонстрационного пользователя. Публичный сайт отдельно. Русский и румынский утверждены для всего интерфейса, включая aria-labels, ошибки, валидацию, даты и пустые состояния. Учебные задания, имена, комментарии и сообщения людей автоматически не переводятся. Язык и таймзона — разные настройки; таймзона берётся из авторитетного контекста пользователя.

Уже есть `packages/ui` с токенами, локальными Golos/Lucide, AppShell/StateBoundary/freshness/refresh, базовыми controls и частичной locale-моделью. `account-ui` остаётся границей меню аккаунта/сессии. В текущем инкременте есть Reports, bell pagination/redirect, current-lesson fix и staff section URLs. Это заготовки и ограниченные доказательства, а не завершение всего плана. Не пересоздавай их с нуля. Сначала сравни фактический код с требованием TASK. Выполненное сохрани и проверь; недостающее реализуй. Исторические числа тестов не считать новым прогоном.

Порядок: основа → ученик → преподаватель → менеджер/CRM → необходимые директор/оператор/общий вход → сквозная приёмка. Отдельные недостающие API-инкременты разрешены владельцем03.11.2026 в рамках утверждённых правил. Старый frontend-only запрет в разделе8 K8K-документа исторический; действующий раздел7 и текущий план имеют приоритет.

## 3. Неприкосновенные правила — применить и в этом TASK

1. Сохрани пользовательский dirty/untracked код и архивы. Никаких `reset --hard`, `clean`, удаления чужих файлов, force push или коммита всего дерева. Сначала прочитай status/HEAD; работай ограниченным diff. Существующую ветку не подменять. Если нужна новая — `codex/k8k-task-NNN` с сохранением рабочей основы; без автоматического merge/push/deploy.
2. Приоритет: последняя явная воля владельца → действующие специальные решения/UX → актуальные архитектурные источники → K8K-инструкции → визуальный template. Замороженные исторические акты не переписывать. Ссылки на отсутствующие handoff/backlog/findings не считать их содержимым или доказательством реализации.
3. Экран ничего сам не подтверждает. Календарь, вход в Meet, факт проведения, право на занятие, денежное поступление, распределение, начисление и выплата — разные факты. Не создавать второй ledger или клиентский расчёт прав.
4. Все действия проверяет сервер по `роль × действие × объект × контекст`. Кнопки строятся по реальной action eligibility/capabilities, не по одной строке роли. Передача поступления менеджером на согласование не директорское подтверждение. Подтверждение поступления/распределения и окончательное финансовое решение — директор.
5. Пока совокупно подтверждённая распределённая оплата абонемента ниже полной цены, каждый частичный/рассрочный допуск требует отдельного ограниченного решения директора. Полная оплата даёт нормальный доступ без двойных прав. Снимок/скриншот платежа семьи не подтверждает оплату.
6. Деньги остаются точными decimal strings/существующим Decimal; никаких `Number`/`parseFloat` для сумм. Не смешивать валюты, аванс, нераспределённые средства семьи, остаток уроков и ожидающие поступления. Чужие дети смешанного портфолио/семьи не раскрываются.
7. Обычная ставка преподавателя: `min(6,floor(eligible_full_months/2)) + min(4,floor(active_students/2))`;0–4→200MDL,5–9→220MDL,10→250MDL. Расчёт только сервером, snapshot при фактическом старте. Восстановление стажа при возвращении в пределах6месяцев. Старые +20/+30,230MDL и месячный пересчёт не возвращать. Спор/предварительное начисление/подтверждённая выплата различаются; личные обещанные обязательства не отменять молча.
8. У ученика нет общего чата/«Моих обращений»/пункта «Сообщения» и отдельного центра уведомлений: только колокольчик. Официальные внешние контакты только из разрешённой CRM-проекции. Спецформы переноса/спора остаются в уроке. Новые внешние организационные автонапоминания семье не вводить.
9. ДЗ и история уроков ученика — единые хронологические списки без новых status-tabs. Сдача не checkbox. Черновик/сохранение/загрузка/отправка/проверка раздельны; существующую сериализованную очередь autosave/версий/idempotency не переписывать ради внешнего вида. Просрочка — текст/иконка, не новая санкция.
10. Навыки: три качественных этапа «Знакомлюсь/Практикую/Применяю» плюс техническое «Ещё не изучали». Ни процентов знаний, рейтинга, автоповышения. Циклы4/8 по подтверждённо проведённым урокам каждого предмета; срез4 не отчёт8; публикация требует преподавателя. Неизвестные ретрокоррекции не решать эвристикой.
11. Истечение одного предмета не закрывает другой; заморозка не окончание, ранее разрешённая самостоятельная работа сохраняется. Полная приостановка — простой экран и контакт менеджера; история не удаляется. Нельзя выводить доступ из названия плана или клиентского состояния.
12. Сохрани действующие CSRF, idempotency, no-store, MFA и явно разрешённые scoped password-only исключения. Одноразовый пароль/OTP/cookie/OAuth token не попадает в logs/stories/snapshots/idempotency cache. Logout/401/session switch убирают приватный DOM/кэш и отменяют reads; поздний ответ прежнего actor отбрасывается.403 выше cached stale.
13. Девять UI-классов: loading, empty, ready, stale, error, pending/unknown-result, forbidden, subscription-limited, session-expired. Loading не empty; queued не delivered; unknown не success. Повтор чтения допустим по политике, слепой повтор команды с неизвестным исходом запрещён. Read≠claim≠resolve; серверная эскалация не зависит от браузера.
14. Токены/шрифт/размеры provisional до приёмки. Golos локально, Lucide статически, без CDN/фото людей/emoji actions. WCAG2.2AA, видимый фокус, клавиатура, reduced-motion, статусы текстом и иконкой;4ширины360/768/1024/1280. Основное действие ученика48px, прочие44px; staff touch44px, desktop от36px по контексту. Не скрывать overflow вместо исправления доступа. Бюджет≤250KiB gzip на маршрут по единому методу с учётом fonts.
15. Новый dependency только по необходимости: pinned версия, релиз старше14дней, license MIT/ISC/BSD/Apache-2.0/OFL; MPL-2.0 только соответствующий test tooling, React18 peers; запись причины/веса вui-stack. Никаких Tailwind/Bootstrap/FullCalendarPremium/AGPL/GPL/CC-NC заимствований. Современный сайт vendor не разрешает обновить текущий stack до latest.
16. Одна рабочая Vercel/Neon main. Не создавать staging/QA/disposable БД, не выполнять reset/seed/destructive/concurrency/crash suites на рабочей БД. Unit/HTTP mocks/local browser fixtures разрешены; перед командой проверь её реальное содержимое и env-target. Не читать/печатать .env. Недоказуемые DB/provider проверки остаются BLOCKED/NOT_RUN, неPASS.
17. Во время отдельного TASK только нужные scoped build/generate/lint/tests и короткий smoke. Общую рекурсивную регрессию отложить до финального блока. Авторизованное API-изменение: source DTO/service/controller → безопасные проверки → штатная OpenAPI/SDK генерация → consumers; generated вручную не править. Applied migrations/checksums не переписывать. Подготовить необходимую additive migration можно с описанием сохранения данных; не применять её к рабочей БД в этой задаче без отдельного разрешения.
18. Условные DIR-01…06 остаются выключенными, DIR-07/BI/P&L вне выпуска. .ics, saved filters, offline/PWA/dark mode тоже вне этого пакета. LEGAL/FIN-LEGAL, ретрокоррекции4/8, expanded MeetAPI POC/OAuth/security/G4 и FND-GATE не закрываются наличием экрана или mock-тестом.

## 4. Источники и конкретные входные файлы

Обязательный локальный минимум, повторённый для отдельного чата:

- [AGENTS.md](../../AGENTS.md) — последние owner decisions, source priority, preservation.
- [PHASE0_CHECKS.md](../../PHASE0_CHECKS.md) — первые актуальные ограничения среды; позднейший исторический список не разрешает testDB.
- [docs/K8K_REDESIGN_PLAN.md](../K8K_REDESIGN_PLAN.md) — объём и последовательность.
- [docs/K8K_IMPLEMENTATION_STATUS.md](../K8K_IMPLEMENTATION_STATUS.md) — какие заготовки уже есть и что ещё не доказано.
- [docs/K8K_REQUIREMENTS_MATRIX.md](../K8K_REQUIREMENTS_MATRIX.md) — текущая трассировка и статусы.
- [docs/K8K_DESIGN_INSTRUCTIONS.md](../K8K_DESIGN_INSTRUCTIONS.md) — разделы2–7; раздел8 исторический, не действующий запрет API.
- [docs/online_academy_CON_01_11_owner_decisions_addendum_v1.0.md](../online_academy_CON_01_11_owner_decisions_addendum_v1.0.md) — CON-01…11: деньги, допуск, ставки, публикация; не возвращать старую модель.

Предметные основания именно этого TASK:

- [docs/K8K_DESIGN_INSTRUCTIONS.md](../K8K_DESIGN_INSTRUCTIONS.md) — **§4 Перетаскивание; §5.3 Канбан**: dnd-kit и обязательная «Переместить в стадию…» альтернатива.
- [apps/api/src/modules/manager/leads/policy.ts](../../apps/api/src/modules/manager/leads/policy.ts) — **leadTransition; LEAD_STAGES**: Реальный граф, terminal и trial prerequisites.
- [apps/api/src/modules/manager/leads/MGR-11.md](../../apps/api/src/modules/manager/leads/MGR-11.md) — **Пробный, skipTrialReason, FIRST_PAYMENT**: 50min free trial, feedback teacher-only, automatic financial conversion.
- [docs/AI Coder Tasks — Модуль 2 — MGR-11.md](../AI%20Coder%20Tasks%20%E2%80%94%20%D0%9C%D0%BE%D0%B4%D1%83%D0%BB%D1%8C%202%20%E2%80%94%20MGR-11.md) — **Команды заявки/пробного**: Существующие карточка/формы/версия.
- [docs/K8K_Academy_UX_decision_register_v0.9.md](../K8K_Academy_UX_decision_register_v0.9.md) — **VIS-08/B, VIS-09/B, VIS-10/B**: Навигация и быстрые действия не расширяют полномочия.

Реальные точки входа в код/доказательства (существуют на дату пакета; если структура позже изменена, найди symbol через `rg`, не создавай дубликат):

- [apps/manager-web/src/pages/Leads.tsx](../../apps/manager-web/src/pages/Leads.tsx).
- [apps/manager-web/src/pages/Lead.tsx](../../apps/manager-web/src/pages/Lead.tsx).
- [apps/manager-web/src/components/lead-form.tsx](../../apps/manager-web/src/components/lead-form.tsx).
- [apps/manager-web/src/hooks/use-command.ts](../../apps/manager-web/src/hooks/use-command.ts).
- [apps/manager-web/src/components/ui.tsx](../../apps/manager-web/src/components/ui.tsx).
- [apps/api/src/modules/manager/leads/policy.ts](../../apps/api/src/modules/manager/leads/policy.ts).
- [apps/manager-web/src/test/handlers.ts](../../apps/manager-web/src/test/handlers.ts).
- [apps/manager-web/src/test/forms.test.tsx](../../apps/manager-web/src/test/forms.test.tsx).
- [packages/ui/src/controls.tsx](../../packages/ui/src/controls.tsx).

Визуальная опора: [template/newtemp.png](../../template/newtemp.png) — язык дизайна, не требования и не источник mock-цифр. Старые [template/*.webp](../../template/README.md) — только исторические примеры.

Инструменты кодера: начинай поиск исходников с `rg`; версии/лицензии проверяй через `pnpm view` и текущий lockfile. Для библиотечных API используй доступный Context7/официальные документы нужной версии; для интерфейса — локальный Playwright/browser harness и проверку реального рендера. Сначала проверь доступность MCP, не считай запись сервера доказательством авторизации. Repo-инструменты и локальные fixtures остаются рабочим fallback. Figma/внешний дизайн-сервис не обязательны для восстановления этого контекста. Не подключай реальные аккаунты/провайдеры ради mock smoke и не подменяй ими ограничения среды.

Официальные справочные сайты по теме; бизнес-контекст уже дан выше, интернет не нужен для его восстановления. Перед использованием API/версии библиотеки сверяй первичную документацию именно совместимой версии. Наличие ссылки не требует установки пакета:

- [React 18.3.1](https://18.react.dev/reference/react) — API текущей major-версии; не обновлять проект до React19 по latest-примеру.
- [TanStack Query v5](https://tanstack.com/query/latest/docs/framework/react/overview) — Чтения, query keys, invalidation, cancellation; выбранную minor сверять с package.json.
- [WCAG 2.2](https://www.w3.org/WAI/WCAG22/quickref/) — Рабочая accessibility-рамка; axe не заменяет ручные проверки.
- [Playwright visual comparisons](https://playwright.dev/docs/test-snapshots) — Воспроизводимые снимки и контролируемые fixtures.
- [Orval](https://orval.dev/) — Генерация SDK только штатным способом проекта.
- [TanStack Table v8](https://tanstack.com/table/v8/docs/introduction) — Headless таблицы, server-controlled pagination/sort.
- [dnd-kit](https://dndkit.com/) — Официальная документация; выбрать совместимую версию/API, а не слепо latest.

## 5. Предметные правила и сохранение поведения

- Mouse drag и клавиатурная «Переместить в стадию…» используют один action dispatcher и один server command/CAS; порядок по колонке не выдумывается как бизнес-приоритет.
- Нельзя вручную CONVERTED: только опубликованное FIRST_PAYMENT распределение. Нельзя входом в TRIAL подделать пробный урок; требуется existing schedule command/teacher/time.
- IN_PROGRESS→AWAITING_PAYMENT без пробного требует skipTrialReason; TRIAL переходы зависят от confirmed teacher outcome. LOST требует причины, reopen сохраняет identity/history.
- Пробный бесплатный50min, contact followup120min и feedback visibility берутся из принятых server config. Manager не пишет исход/feedback и не списывает trial как paid lesson.
- Дубликат предупреждает, forceCreate требует явного выбора и Audit; контакты не объединяют сущности автоматически.
- Во время pending/unknown карточка не считается перемещённой успешно; rollback visual preview не означает rollback server command. Сначала сверка текущего объекта, не новый UUID вслепую.

## 6. Контракты, данные и совместимость

- Используются существующие lead command SDK и stable intent UUID; если action требует schedule/lost reason/skip reason, dnd не обходит форму или validation.
- List version/source/current actions серверные; client optimistic preview не меняет confirmed counts и не служит основанием последующей команды.
- CONVERTED и teacher trial outcome не имеют manager stage setter. Внешние CONTACT уведомления остаются отдельным утверждённым процессом MGR-08, drag их сам не отправляет.
- Dnd dependency подключается лениво на board route, без нового CSS framework; table и keyboard не зависят от наличия pointer device.

Точные имена новых planned DTO/operation/props запиши в коротком design note этого TASK до реализации и соблюдай существующие namespace/style. Planned нельзя выдавать за уже существующий API. Найденный существующий сервис переиспользуй. Generic UI не принимает бизнес-решения. Существующий авторитетный источник не копируется во второй реестр.

## 7. Пошаговое выполнение

1. Подтверди prerequisites по реальным артефактам предыдущих TASK и текущему коду. Недостающий результат не заменяй заглушкой или флагом с фиктивными данными. Не пересылай пользователю уже закрытые вопросы о чате, уведомлениях или director-only подтверждениях.
2. Подключить per-column pages/counts TASK-053 и сохранить table view. URL хранит view/base filters; загрузка следующей колонки не сбрасывает другие cursors/scroll.
3. Добавить accessible action menu на каждой карточке с разрешёнными targets и понятными reasons disabled. Получить current version из list/detail, не вычислять её локально.
4. Связать target transitions с existing claim/transition/lose/reopen/schedule-trial forms: где нужны дополнительные поля, открывать ту же форму и сохранять target intent.
5. Подключить dnd-kit только после pinned/license/React/age/bundle checks общего taskpack; drag hover — визуальное предложение, drop запускает общий dispatcher, не mutates stage напрямую.
6. Сделать клавиатурный эквивалент и screen-reader announcements: текущая/целевая стадия, pending/confirmed/error. На touch использовать action menu без требования точного dragging.
7. Обрабатывать conflict409: сохранить ввод причины/времени, refetch card/actions, объяснить новую версию; forbidden/portfolio revoked скрывает карточку, не возвращает её из optimistic array.
8. После success invalidate обе колонки/matching counts/detail/summary из авторитетного ответа; избежать double cards и неверного total при появлении карточки на незагруженной странице.
9. Перевести titles/aria/transition reasons RU/RO, сохранить child/adult поля и guardian validation. Проверить table/board/lead detail/Back context на четырёх ширинах и keyboard-only.
10. Сверь итог с правилами разделов3/5/6 этого же файла, обнови журнал и предметную матрицу, подготовь артефакты и остановись после отчёта по TASK-054.

## 8. Обязательные сценарии проверки

- [ ] Keyboard menu и mouse drop на разрешённый target вызывают одинаковый endpoint/body/version.
- [ ] Drop в CONVERTED не создаёт ручную конверсию; TRIAL требует teacher/time form.
- [ ] Skip trial без reason/LOST без reason/неподтверждённый trial outcome отклоняются без ложного перемещения.
- [ ] Stale version409 сохраняет ввод и refetch, denied scope удаляет card.
- [ ] Double click/drop/unknown retry не создают вторую trial/task/transition; confirmed counts не optimistic.
- [ ] Pagination per stage сохраняется при board/table переключении; matched count не равен loaded count.
- [ ] Keyboard/screen-reader/touch/RU/RO/360px сценарии возможны без drag.

Для визуального изменения: RU/RO,360/768/1024/1280, keyboard/focus/long text и relevant VIS11 states. Для read-model/API: validation, own/foreign scope, revoked context, no-store, error/empty/unknown и совместимость SDK. Для мутации: CSRF/idempotency/revision/unknown-result и отсутствие двойного эффекта. Не добавляй бессмысленный тест, который просто повторяет строку implementation; доказывай поведение.

## 9. Команды и безопасные границы проверки

Рабочий каталог `D:/OnlineSchool`. Это адресные ориентиры из текущих manifests, а не разрешение слепо запускать все команды. Прочитай scripts/конфиг теста перед запуском. Сборка может генерировать Prisma/SDK; это не разрешение запускать migration/seed или подключать реальную БД. Dist-based tests выполнять после целевой сборки.

```powershell
pnpm test:mgr11
```

```powershell
pnpm --filter @online-school/manager-web typecheck
```

```powershell
pnpm --filter @online-school/manager-web test:unit
```

- Создать адресный Playwright grep lead-board-keyboard-dnd на local MSW fixtures.

Если нужен новый тестовый script, сначала добавь его в manifest с явно безопасным локальным/mock target, затем запусти и запиши точную команду. Не выполняй `pnpm test`/recursive regression автоматически на каждом TASK. Полный разрешённый прогон относится к финальному блоку. Ошибка не основание ослабить линтер или выдавать NOT_RUN за PASS.

## 10. Критерии готовности

- [ ] Есть полная клавиатурная альтернатива всем drag действиям.
- [ ] Ни один переход не обходит утверждённый server graph/form/version/capability.
- [ ] Pending/unknown/conflict не отображаются как подтверждённая новая стадия.
- [ ] После успеха counts/колонки/detail согласованы с сервером без дублей.
- [ ] Board/table mobile/RURO доступны и укладываются в общий route budget.

- [ ] Все использованные данные и действия имеют реальный авторитетный источник/проверку; нет выдуманных цифр, прав, кнопок и success.
- [ ] Отчёт различает исходный работающий код, новые изменения, свежие проверки и исторические доказательства.
- [ ] Не изменены рабочая БД, применённые migration checksums и production; необоснованные внешние эффекты отсутствуют.

## 11. Не входит в этот TASK

- Произвольное редактирование стадии, manual CONVERTED, teacher outcome mutation и платный trial.
- Автоматическое объединение лидов, новые SLA и новые внешние сообщения семье.

Обнаруженный соседний gap запиши с конкретным следующим TASK, не расширяй текущую задачу на весь redesign. Если требуется реально новое бизнес-решение или недоступный внешний провайдер — подготовь все независимые изменения и точный вопрос/блокер только по этому пункту. Не останавливайся на повторном согласовании ранее утверждённых правил.

## 12. Артефакты и отчёт для следующего кодера

- output/k8k-taskpack/task-054/report.md: commit, изменения, команды и ограничения; отрицательные/непроверенные случаи явно указаны.
- output/k8k-taskpack/task-054/acceptance.json: PASS/FAIL/NOT_RUN каждого критерия со ссылкой на fixture/HTTP/browser evidence.

Формат `output/k8k-tasks/TASK-054/report.md`:

```text
TASK: TASK-054
Статус: DONE / PARTIAL / BLOCKED (не смешивать с исходным статусом заготовки)
Основа: HEAD, ветка, dirty digest, сохранённые чужие изменения
Что уже существовало:
Что изменено: путь → поведение → причина
Контракты/SDK/миграции: actual changes, совместимость, что не применялось
Источники/решения: конкретные IDs и применённый приоритет
Проверки: команда → exit code → сценарии → artifact path
Визуальные доказательства: route, role, locale, viewport, fixture
Не проверено/блокеры: точная причина и необходимое внешнее условие
Acceptance checklist: каждый критерий PASS / FAIL / NOT_RUN
Остатки: конкретный TASK и передаваемые interfaces/URLs/ключи
Риски и обратимость: ограниченный rollback без удаления истории/чужих файлов
```

После отчёта остановись. Следующий TASK выдаёт владелец отдельно. Не добавляй утверждение о FND-GATE/юридическом соответствии/production GO, если такого доказательства и решения нет.
