# TASK-069 — Cross-role gate: director/operator/auth RU/RO, безопасность решений и открытые внешние зависимости

**Пакет:** K8K-FRONTEND-REBUILD v1.0,03.11.2026. **Блок:** 6 — Директор, оператор, вход и приватность. **Модуль:** Приёмка директора, оператора и общей безопасности.

**Входные зависимости:** [TASK-059](TASK-059.md), [TASK-060](TASK-060.md), [TASK-061](TASK-061.md), [TASK-062](TASK-062.md), [TASK-063](TASK-063.md), [TASK-064](TASK-064.md), [TASK-065](TASK-065.md), [TASK-066](TASK-066.md), [TASK-067](TASK-067.md), [TASK-068](TASK-068.md). Номер относится только к этому пакету, не к старым MGR/Phase0 TASK. **Учёт выполнения:** [EXECUTION_LOG](EXECUTION_LOG.md).

**Исходный статус:** Есть целевые manager/student/security/switch suites и прежние read-only platform smoke. Полной приёмки новых director команд, operator diagnostics, общей auth UI и privacy ещё нет. Расширенный Meet API/OAuth/POC относится к отдельной зависимости TASK-074; правовой/foundation gate этим блоком не закрывается.. Это описание кода на дату составления, не акт приёмки и не команда начать с нуля.

## 1. Команда AI-кодеру и результат

Выполни **только TASK-069** в существующем репозитории. Не начинай следующий TASK автоматически.

Принять операционный инкремент целиком по ролям и совместимости: director finance/schedule/dispute/period, operator safe diagnostics, auth/MFA/recovery, demo switching и privacy entry на RU/RO. Отделить реализованное и проверенное от условного, заблокированного и внешнего.

Этот файл содержит необходимые общие правила и предметное задание. Предыдущая переписка, ответы других чатов и внешний COMMON.md не нужны. Локальные исходники/документы ниже нужны для проверки фактической реализации; их ссылки не заменяют сформулированные здесь требования. Если код уже частично существует — ревью, завершение и доказательство вместо повторной реализации.

## 2. Контекст проекта — повторён намеренно

Рабочий репозиторий `D:/OnlineSchool`, существующее ESM pnpm-monorepo. Это функциональный редизайн работающей академии, а не новый проект. Node24, pnpm10.34.9, React18.3.1, Vite7.3.7, TypeScript6.0.3 strict, NestJS/Prisma, PostgreSQL, TanStackQuery и сгенерированный Orval SDK уже используются. Проверяй текущие manifests: перечисленные версии описывают исходную точку пакета03.11.2026, не команду массово обновить зависимости.

В выпуск входят пять кабинетов, общий вход и смена демонстрационного пользователя. Публичный сайт отдельно. Русский и румынский утверждены для всего интерфейса, включая aria-labels, ошибки, валидацию, даты и пустые состояния. Учебные задания, имена, комментарии и сообщения людей автоматически не переводятся. Язык и таймзона — разные настройки; таймзона берётся из авторитетного контекста пользователя.

Уже есть `packages/ui` с токенами, локальными Golos/Lucide, AppShell/StateBoundary/freshness/refresh, базовыми controls и частичной locale-моделью. `account-ui` остаётся границей меню аккаунта/сессии. В текущем инкременте есть Reports, bell pagination/redirect, current-lesson fix и staff section URLs. Это заготовки и ограниченные доказательства, а не завершение всего плана. Не пересоздавай их с нуля. Сначала сравни фактический код с требованием TASK. Выполненное сохрани и проверь; недостающее реализуй. Исторические числа тестов не считать новым прогоном.

Порядок: основа → ученик → преподаватель → менеджер/CRM → необходимые директор/оператор/общий вход → сквозная приёмка. Отдельные недостающие API-инкременты разрешены владельцем03.11.2026 в рамках утверждённых правил. Старый frontend-only запрет в разделе8 K8K-документа исторический; действующий раздел7 и текущий план имеют приоритет.

## 3. Неприкосновенные правила — применить и в этом TASK

1. Сохрани пользовательский dirty/untracked код и архивы. Никаких `reset --hard`, `clean`, удаления чужих файлов, force push или коммита всего дерева. Сначала прочитай status/HEAD; работай ограниченным diff. Существующую ветку не подменять. Если нужна новая — `codex/k8k-task-NNN` с сохранением рабочей основы; без автоматического merge/push/deploy.
2. Приоритет: последняя явная воля владельца → действующие специальные решения/UX → актуальные архитектурные источники → K8K-инструкции → визуальный template. Замороженные исторические акты не переписывать. Ссылки на отсутствующие handoff/backlog/findings не считать их содержимым или доказательством реализации.
3. Экран ничего сам не подтверждает. Календарь, вход в Meet, факт проведения, право на занятие, денежное поступление, распределение, начисление и выплата — разные факты. Не создавать второй ledger или клиентский расчёт прав.
4. Все действия проверяет сервер по `роль × действие × объект × контекст`. Кнопки строятся по реальной action eligibility/capabilities, не по одной строке роли. Передача поступления менеджером на согласование не директорское подтверждение. Подтверждение поступления/распределения и окончательное финансовое решение — директор.
5. Пока совокупно подтверждённая распределённая оплата абонемента ниже полной цены, каждый частичный/рассрочный допуск требует отдельного ограниченного решения директора. Полная оплата даёт нормальный доступ без двойных прав. Снимок/скриншот платежа семьи не подтверждает оплату.
6. Деньги остаются точными decimal strings/существующим Decimal; никаких `Number`/`parseFloat` для сумм. Не смешивать валюты, аванс, нераспределённые средства семьи, остаток уроков и ожидающие поступления. Чужие дети смешанного портфолио/семьи не раскрываются.
7. Обычная ставка преподавателя: `min(6,floor(eligible_full_months/2)) + min(4,floor(active_students/2))`;0–4→200MDL,5–9→220MDL,10→250MDL. Расчёт только сервером, snapshot при фактическом старте. Восстановление стажа при возвращении в пределах6месяцев. Старые +20/+30,230MDL и месячный пересчёт не возвращать. Спор/предварительное начисление/подтверждённая выплата различаются; личные обещанные обязательства не отменять молча.
8. У ученика нет общего чата/«Моих обращений»/пункта «Сообщения» и отдельного центра уведомлений: только колокольчик. Официальные внешние контакты только из разрешённой CRM-проекции. Спецформы переноса/спора остаются в уроке. Новые внешние организационные автонапоминания семье не вводить.
9. ДЗ и история уроков ученика — единые хронологические списки без новых status-tabs. Сдача не checkbox. Черновик/сохранение/загрузка/отправка/проверка раздельны; существующую сериализованную очередь autosave/версий/idempotency не переписывать ради внешнего вида. Просрочка — текст/иконка, не новая санкция.
10. Навыки: три качественных этапа «Знакомлюсь/Практикую/Применяю» плюс техническое «Ещё не изучали». Ни процентов знаний, рейтинга, автоповышения. Циклы4/8 по подтверждённо проведённым урокам каждого предмета; срез4 не отчёт8; публикация требует преподавателя. Неизвестные ретрокоррекции не решать эвристикой.
11. Истечение одного предмета не закрывает другой; заморозка не окончание, ранее разрешённая самостоятельная работа сохраняется. Полная приостановка — простой экран и контакт менеджера; история не удаляется. Нельзя выводить доступ из названия плана или клиентского состояния.
12. Сохрани действующие CSRF, idempotency, no-store, MFA и явно разрешённые scoped password-only исключения. Одноразовый пароль/OTP/cookie/OAuth token не попадает в logs/stories/snapshots/idempotency cache. Logout/401/session switch убирают приватный DOM/кэш и отменяют reads; поздний ответ прежнего actor отбрасывается.403 выше cached stale.
13. Девять UI-классов: loading, empty, ready, stale, error, pending/unknown-result, forbidden, subscription-limited, session-expired. Loading не empty; queued не delivered; unknown не success. Повтор чтения допустим по политике, слепой повтор команды с неизвестным исходом запрещён. Read≠claim≠resolve; серверная эскалация не зависит от браузера.
14. Токены/шрифт/размеры provisional до приёмки. Golos локально, Lucide статически, без CDN/фото людей/emoji actions. WCAG2.2AA, видимый фокус, клавиатура, reduced-motion, статусы текстом и иконкой;4ширины360/768/1024/1280. Основное действие ученика48px, прочие44px; staff touch44px, desktop от36px по контексту. Не скрывать overflow вместо исправления доступа. Бюджет≤250KiB gzip на маршрут по единому методу с учётом fonts.
15. Новый dependency только по необходимости: pinned версия, релиз старше14дней, license MIT/ISC/BSD/Apache-2.0/OFL; MPL-2.0 только соответствующий test tooling, React18 peers; запись причины/веса вui-stack. Никаких Tailwind/Bootstrap/FullCalendarPremium/AGPL/GPL/CC-NC заимствований. Современный сайт vendor не разрешает обновить текущий stack до latest.
16. Одна рабочая Vercel/Neon main. Не создавать staging/QA/disposable БД, не выполнять reset/seed/destructive/concurrency/crash suites на рабочей БД. Unit/HTTP mocks/local browser fixtures разрешены; перед командой проверь её реальное содержимое и env-target. Не читать/печатать .env. Недоказуемые DB/provider проверки остаются BLOCKED/NOT_RUN, неPASS.
17. Во время отдельного TASK только нужные scoped build/generate/lint/tests и короткий smoke. Общую рекурсивную регрессию отложить до финального блока. Авторизованное API-изменение: source DTO/service/controller → безопасные проверки → штатная OpenAPI/SDK генерация → consumers; generated вручную не править. Applied migrations/checksums не переписывать. Подготовить необходимую additive migration можно с описанием сохранения данных; не применять её к рабочей БД в этой задаче без отдельного разрешения.
18. Условные DIR-01…06 остаются выключенными, DIR-07/BI/P&L вне выпуска. .ics, saved filters, offline/PWA/dark mode тоже вне этого пакета. LEGAL/FIN-LEGAL, ретрокоррекции4/8, expanded MeetAPI POC/OAuth/security/G4 и FND-GATE не закрываются наличием экрана или mock-тестом.

## 4. Источники и конкретные входные файлы

Обязательный локальный минимум, повторённый для отдельного чата:

- [AGENTS.md](../../AGENTS.md) — последние owner decisions, source priority, preservation.
- [PHASE0_CHECKS.md](../../PHASE0_CHECKS.md) — первые актуальные ограничения среды; позднейший исторический список не разрешает testDB.
- [docs/K8K_REDESIGN_PLAN.md](../K8K_REDESIGN_PLAN.md) — объём и последовательность.
- [docs/K8K_IMPLEMENTATION_STATUS.md](../K8K_IMPLEMENTATION_STATUS.md) — какие заготовки уже есть и что ещё не доказано.
- [docs/K8K_REQUIREMENTS_MATRIX.md](../K8K_REQUIREMENTS_MATRIX.md) — текущая трассировка и статусы.
- [docs/K8K_DESIGN_INSTRUCTIONS.md](../K8K_DESIGN_INSTRUCTIONS.md) — разделы2–7; раздел8 исторический, не действующий запрет API.
- [docs/online_academy_CON_01_11_owner_decisions_addendum_v1.0.md](../online_academy_CON_01_11_owner_decisions_addendum_v1.0.md) — CON-01…11: деньги, допуск, ставки, публикация; не возвращать старую модель.

Предметные основания именно этого TASK:

- [docs/K8K_DESIGN_INSTRUCTIONS.md](../K8K_DESIGN_INSTRUCTIONS.md) — **2–6**: K8K источники/запреты/tokens/инструменты/приёмка
- [docs/K8K_Academy_VIS12_dashboard_module_contracts_v1.0.md](../K8K_Academy_VIS12_dashboard_module_contracts_v1.0.md) — **5–8**: Conditional DIR scope и отрицательные cross-role tests
- [docs/online_academy_MVP_full_release_architecture_roadmap_v9.7.md](../online_academy_MVP_full_release_architecture_roadmap_v9.7.md) — **41;ARCH-31/B**: Последовательные QA gates и отдельная release приёмка
- [PHASE0_CHECKS.md](../../PHASE0_CHECKS.md) — **Current allowed environment**: Без testDB/destructive working suites
- [docs/online_academy_REL-01_A_Meet_API_MVP_release_addendum_v1.0.md](../online_academy_REL-01_A_Meet_API_MVP_release_addendum_v1.0.md) — **Scope/gates**: Meet URL/fallback не означает G4 API/OAuth PASS
- [docs/online_academy_block_13_final_architecture_handoff_v1.0.md](../online_academy_block_13_final_architecture_handoff_v1.0.md) — **Open dependencies**: LEGAL/FIN-LEGAL/LANG/OPS и production GO отдельно

Реальные точки входа в код/доказательства (существуют на дату пакета; если структура позже изменена, найди symbol через `rg`, не создавай дубликат):

- [apps/platform/src/App.tsx](../../apps/platform/src/App.tsx).
- [packages/account-ui/src/index.tsx](../../packages/account-ui/src/index.tsx).
- [apps/api/src/modules/platform/platform.module.ts](../../apps/api/src/modules/platform/platform.module.ts).
- [apps/api/src/modules/identity/identity.controller.ts](../../apps/api/src/modules/identity/identity.controller.ts).
- [apps/api/src/modules/qa/qa.module.ts](../../apps/api/src/modules/qa/qa.module.ts).
- [apps/api/src/modules/finance/periods.service.ts](../../apps/api/src/modules/finance/periods.service.ts).
- [tests/FOUNDATION_STATUS.json](../../tests/FOUNDATION_STATUS.json).
- [playwright.config.mjs](../../playwright.config.mjs).
- [tests/unit/platform-switch-http.test.mjs](../../tests/unit/platform-switch-http.test.mjs).
- [tests/unit/target-guards.test.mjs](../../tests/unit/target-guards.test.mjs).
- [tests/unit/http-transport.test.mjs](../../tests/unit/http-transport.test.mjs).

Визуальная опора: [template/newtemp.png](../../template/newtemp.png) — язык дизайна, не требования и не источник mock-цифр. Старые [template/*.webp](../../template/README.md) — только исторические примеры.

Инструменты кодера: начинай поиск исходников с `rg`; версии/лицензии проверяй через `pnpm view` и текущий lockfile. Для библиотечных API используй доступный Context7/официальные документы нужной версии; для интерфейса — локальный Playwright/browser harness и проверку реального рендера. Сначала проверь доступность MCP, не считай запись сервера доказательством авторизации. Repo-инструменты и локальные fixtures остаются рабочим fallback. Figma/внешний дизайн-сервис не обязательны для восстановления этого контекста. Не подключай реальные аккаунты/провайдеры ради mock smoke и не подменяй ими ограничения среды.

Официальные справочные сайты по теме; бизнес-контекст уже дан выше, интернет не нужен для его восстановления. Перед использованием API/версии библиотеки сверяй первичную документацию именно совместимой версии. Наличие ссылки не требует установки пакета:

- [React 18.3.1](https://18.react.dev/reference/react) — API текущей major-версии; не обновлять проект до React19 по latest-примеру.
- [TanStack Query v5](https://tanstack.com/query/latest/docs/framework/react/overview) — Чтения, query keys, invalidation, cancellation; выбранную minor сверять с package.json.
- [WCAG 2.2](https://www.w3.org/WAI/WCAG22/quickref/) — Рабочая accessibility-рамка; axe не заменяет ручные проверки.
- [Playwright visual comparisons](https://playwright.dev/docs/test-snapshots) — Воспроизводимые снимки и контролируемые fixtures.
- [Orval](https://orval.dev/) — Генерация SDK только штатным способом проекта.
- [Google Meet API](https://developers.google.com/workspace/meet/api/guides/overview) — Provider/OAuth ограничения отдельно от права открыть урок; не разрешение собирать все доступные Google данные.
- [CNPDCP — закон195/2024](https://datepersonale.md/despre-legea-nr-195-2024/) — Официальный правовой источник Молдовы для отдельной legal-проверки. Задание не подменяет юридическое заключение.

## 5. Предметные правила и сохранение поведения

- Директор, оператор, manager, teacher и student проверяются как разные серверные authority, а не только разные меню; прямые API/URL/export/file paths включены.
- Conditional DIR-01…06 и POST-MVP DIR-07 не считаются обязательным реализованным MVP без scope решения; недостающий source не заполняется mock KPI.
- UNKNOWN financial/provider исход не даёт повторить эффект новым ключом; approval/read/close не равны apply/paid/resolve.
- Безопасные mocks/fixtures/unit/HTTP/browser не используют working Neon для write; real-origin smoke ограничен разрешённым чтением, новой QA/staging БД нет.
- Gate каждого workflow имеет evidence текущей версии, дефекты/retеst и непроверенные случаи; прежний smoke не импортируется как доказательство новых write-команд.
- Meet URL/button/fallback не закрывает expanded API/OAuth/POC/security/G4; эта зависимость связана с TASK-074 и остаётся отдельным статусом.
- Правовые материалы/переводы/retention/processor approvals, FND/DB race/restore и production GO не объявляются пройденными автоматически.
- RU/RO и WCAG keyboard/contrast/zoom/reduced-motion обязательны по UI; автоматический axe сам по себе не доказывает полное соответствие.

## 6. Контракты, данные и совместимость

- Acceptance проверяет фактические новые/существующие OpenAPI+SDK контракты без ручного fetch/generated edits; role capability metadata едины с foundation018.
- Fixture environment должен жёстко исключать working DATABASE_URL/provider writes; live smoke имеет явный read-only whitelist без финансовых команд.
- Gate output сохраняет current code/branch/worktree version, язык/viewport/role/case/result/evidence и ограничения; секреты/proof/private child content исключены.
- Критерий DONE TASK-062 включает согласованный backend closing behaviour; статус pure frontend готовности не подменяет предметную приёмку.
- External dependency register содержит ссылку на TASK-074 и legal/FND gates; существующая production публикация и health ok не считаются разрешением полного MVP GO.

Точные имена новых planned DTO/operation/props запиши в коротком design note этого TASK до реализации и соблюдай существующие namespace/style. Planned нельзя выдавать за уже существующий API. Найденный существующий сервис переиспользуй. Generic UI не принимает бизнес-решения. Существующий авторитетный источник не копируется во второй реестр.

## 7. Пошаговое выполнение

1. Подтверди prerequisites по реальным артефактам предыдущих TASK и текущему коду. Недостающий результат не заменяй заглушкой или флагом с фиктивными данными. Не пересылай пользователю уже закрытые вопросы о чате, уведомлениях или director-only подтверждениях.
2. Собрать matrix TASK-059…068 → canonical requirement → role/action/resource/context → endpoint/UI → case/evidence/status, включая backend OPS-02 изменение TASK-062.
3. Пройти director receipt/distribution/admission и schedule/dispute workflows с текущей revision, distinct effects, replay и stale/unknown; проверить manual partial и forbidden cross-role.
4. Пройти confirmed-part period closing с отдельным unresolved register, late authorised correction и pending/UNKNOWN provider reconciliation; если TASK-062 backend blocked, не ставить этому workflow PASS по UI.
5. Пройти operator API/DB/worker состояния, stale/not-checked/privacy; проверить, что экран не вызывает restart/job replay/finance и не обещает readiness.
6. Пройти password→MFA/recovery/force-change→cabinet, expired/revoked/recovery-only, one-time proof и cross-tab demo switch/logout; invalid return/role/flags не обходят policies.
7. Проверить privacy/data-rights/suspended contact и legal drafts: нет ложного representative consent/auto retention/delete или новых student чат/appeal меню.
8. Пройти RU/RO всех критических состояний и четырёх viewport360/768/1024/1280; keyboard/screen-reader sample/zoom200%/contrast/focus/reduced-motion и narrow finance tables.
9. Запустить scoped unit/HTTP/SDK/browser fixtures, regression затронутых student/teacher/manager/common сценариев; не повторять весь recursive gate по каждой задаче.
10. Измерить route gzip≤250КиБ и реальные ошибки accessibility, исправить дефекты с targeted retest; screenshot evidence хранить без секретов/PII.
11. Подготовить итоговый status register: implemented/tested/partial/blocked/deferred по задачам, Meet074/legal/FND/realDB prerequisites и rollback. Не merge/deploy и не выдавать production GO этой приёмкой.
12. Сверь итог с правилами разделов3/5/6 этого же файла, обнови журнал и предметную матрицу, подготовь артефакты и остановись после отчёта по TASK-069.

## 8. Обязательные сценарии проверки

- [ ] Director полномочия confirm/approve/admission/close доступны только соответствующему actor+MFA; manager/operator/student не исполняют их прямым запросом.
- [ ] Exact schedule revision и versioned dispute сохраняют разовые эффекты, partial manual не исполняется как full reversal.
- [ ] Partial/full cumulative payment и отдельный admission не дублируют права; unknown outcome/replay не дублирует ledger/task.
- [ ] Period confirmed-part closing сохраняет спор, late correction не переписывает историю; provider UNKNOWN не помечается paid.
- [ ] Operator diagnostics не раскрывает PII/secrets/SQL и не даёт финансового/образовательного доступа.
- [ ] Auth recovery proof одноразовый, registration-only session закрыта от кабинета, flags/returnUrl/role spoofing не повышают права.
- [ ] Несколько вкладок после switch/logout/revoke очищают прежние queries/DOM и не рендерят поздний private response.
- [ ] RU/RO, keyboard/focus/zoom200%/contrast/reduced-motion и четыре widths проходят важные формы/таблицы/диалоги.
- [ ] Нет условных KPI/P&L/чата ученика/auto-family org messages/auto-delete, нет ложного G4/legal/FND PASS.

Для визуального изменения: RU/RO,360/768/1024/1280, keyboard/focus/long text и relevant VIS11 states. Для read-model/API: validation, own/foreign scope, revoked context, no-store, error/empty/unknown и совместимость SDK. Для мутации: CSRF/idempotency/revision/unknown-result и отсутствие двойного эффекта. Не добавляй бессмысленный тест, который просто повторяет строку implementation; доказывай поведение.

## 9. Команды и безопасные границы проверки

Рабочий каталог `D:/OnlineSchool`. Это адресные ориентиры из текущих manifests, а не разрешение слепо запускать все команды. Прочитай scripts/конфиг теста перед запуском. Сборка может генерировать Prisma/SDK; это не разрешение запускать migration/seed или подключать реальную БД. Dist-based tests выполнять после целевой сборки.

```powershell
pnpm --filter @online-school/platform typecheck
```

```powershell
pnpm --filter @online-school/platform lint
```

```powershell
pnpm --filter @online-school/platform build
```

```powershell
pnpm --filter @online-school/account-ui typecheck
```

```powershell
node --experimental-vm-modules node_modules/jest/bin/jest.js tests/unit/platform-switch-http.test.mjs tests/unit/target-guards.test.mjs tests/unit/http-transport.test.mjs tests/unit/manager-payments-http.test.mjs tests/unit/manager-schedule-http.test.mjs tests/unit/manager-tasks-http.test.mjs --runInBand
```

```powershell
pnpm exec playwright test --list
```

Если нужен новый тестовый script, сначала добавь его в manifest с явно безопасным локальным/mock target, затем запусти и запиши точную команду. Не выполняй `pnpm test`/recursive regression автоматически на каждом TASK. Полный разрешённый прогон относится к финальному блоку. Ошибка не основание ослабить линтер или выдавать NOT_RUN за PASS.

## 10. Критерии готовности

- [ ] Операционные director/operator/auth/privacy workflows имеют текущие evidence и честный gate status.
- [ ] Критические дефекты исправлены с ретестом, заблокированные зависимости явно перечислены.
- [ ] Cross-role server isolation и private session lifecycle подтверждены адресно.
- [ ] RU/RO, доступность и route budget проверены, таблицы/диалоги пригодны на узких экранах.
- [ ] Conditional DIR modules и внешние Meet/legal/FND gates не объявлены реализованными/закрытыми без доказательств.
- [ ] OPS-02 backend scope принят либо TASK-062 остаётся явно blocked/partial; нет ложного DONE от одного UI.
- [ ] Reviewable diff/rollback и список оставшихся release условий переданы без автоматического merge/deploy.

- [ ] Все использованные данные и действия имеют реальный авторитетный источник/проверку; нет выдуманных цифр, прав, кнопок и success.
- [ ] Отчёт различает исходный работающий код, новые изменения, свежие проверки и исторические доказательства.
- [ ] Не изменены рабочая БД, применённые migration checksums и production; необоснованные внешние эффекты отсутствуют.

## 11. Не входит в этот TASK

- Полный RELEASE-GATE и production GO, expanded Google provider implementation TASK-074
- Destructive рабочая PostgreSQL, новое QA/staging окружение и реальные деньги
- Юридическая сертификация, бухгалтерская экспертиза и автоматическое утверждение условных KPI

Обнаруженный соседний gap запиши с конкретным следующим TASK, не расширяй текущую задачу на весь redesign. Если требуется реально новое бизнес-решение или недоступный внешний провайдер — подготовь все независимые изменения и точный вопрос/блокер только по этому пункту. Не останавливайся на повторном согласовании ранее утверждённых правил.

## 12. Артефакты и отчёт для следующего кодера

- Director/operator/auth/privacy cross-role RU/RO gate matrix и evidence
- OPS-02/Meet074/LEGAL/FIN-LEGAL/LANG/FND/realDB current status register
- Bundle/accessibility/defects-retest report и rollback plan

Формат `output/k8k-tasks/TASK-069/report.md`:

```text
TASK: TASK-069
Статус: DONE / PARTIAL / BLOCKED (не смешивать с исходным статусом заготовки)
Основа: HEAD, ветка, dirty digest, сохранённые чужие изменения
Что уже существовало:
Что изменено: путь → поведение → причина
Контракты/SDK/миграции: actual changes, совместимость, что не применялось
Источники/решения: конкретные IDs и применённый приоритет
Проверки: команда → exit code → сценарии → artifact path
Визуальные доказательства: route, role, locale, viewport, fixture
Не проверено/блокеры: точная причина и необходимое внешнее условие
Acceptance checklist: каждый критерий PASS / FAIL / NOT_RUN
Остатки: конкретный TASK и передаваемые interfaces/URLs/ключи
Риски и обратимость: ограниченный rollback без удаления истории/чужих файлов
```

После отчёта остановись. Следующий TASK выдаёт владелец отдельно. Не добавляй утверждение о FND-GATE/юридическом соответствии/production GO, если такого доказательства и решения нет.
